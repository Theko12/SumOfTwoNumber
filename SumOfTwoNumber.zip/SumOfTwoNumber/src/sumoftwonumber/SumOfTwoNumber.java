
package sumoftwonumber;

import java.util.Scanner;

public class SumOfTwoNumber {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Declaration of my variables
        int num1, num2, sum;
        
        Scanner sc = new Scanner(System.in);
        
        //Prompt the user for input
        System.out.println("Please enter the first number: ");
        num1 = sc.nextInt();
        System.out.println("Please enter the second number: ");
        num2 = sc.nextInt();
        
        //Determine the sum of num1 and num2
        sum = num1 + num2;
        
        System.out.println("The sum of num1 and num2 is: "+sum);
                }
    
}
